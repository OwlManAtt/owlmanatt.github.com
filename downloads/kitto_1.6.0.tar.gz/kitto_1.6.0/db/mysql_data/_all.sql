-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `avatar`
--

LOCK TABLES `avatar` WRITE;
/*!40000 ALTER TABLE `avatar` DISABLE KEYS */;
INSERT INTO `avatar` (`avatar_id`, `avatar_name`, `avatar_image`, `active`) VALUES (1,'Kitto','kitto.png','Y'),(2,'Zutto','zutto.png','Y');
/*!40000 ALTER TABLE `avatar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `board_category`
--

LOCK TABLES `board_category` WRITE;
/*!40000 ALTER TABLE `board_category` DISABLE KEYS */;
INSERT INTO `board_category` (`board_category_id`, `category_name`, `order_by`, `required_permission_id`) VALUES (1,'General',0,0),(2,'Advertising',1,0),(3,'Private Boards',100,13);
/*!40000 ALTER TABLE `board_category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` (`board_id`, `board_category_id`, `board_name`, `board_descr`, `board_locked`, `news_source`, `required_permission_id`, `order_by`) VALUES (1,1,'News & Announcements','The latest news and annoucements are posted here.','Y','Y',0,1),(2,1,'General Chat','Discuss the KittoKittoKitto project here.','N','N',0,3),(3,1,'Suggestions / Bugs','Found a bug? Have a brilliant, earth-shattering idea? Tell us!','N','N',0,6),(4,3,'Staff Board','This is a board restricted to staff members.','N','N',13,100),(5,2,'For Sale','Awesome deals on today\'s hottest products.','N','N',0,0),(6,2,'Groups','Organization for player-run groups.','N','N',0,1);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `cron_tab`
--

LOCK TABLES `cron_tab` WRITE;
/*!40000 ALTER TABLE `cron_tab` DISABLE KEYS */;
INSERT INTO `cron_tab` (`cron_tab_id`, `cron_class`, `cron_frequency_seconds`, `unixtime_next_run`, `enabled`) VALUES (1,'Job_RestockShops',3600,1247524173,'Y'),(2,'Job_UserOnline',300,1247522496,'Y');
/*!40000 ALTER TABLE `cron_tab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `datetime_format`
--

LOCK TABLES `datetime_format` WRITE;
/*!40000 ALTER TABLE `datetime_format` DISABLE KEYS */;
INSERT INTO `datetime_format` (`datetime_format_id`, `datetime_format_name`, `datetime_format`) VALUES (1,'YYYY-MM-DD 24:MM:SS','Y-m-d H:i:s'),(2,'YYYY-MM-DD 12:MM:SS','Y-m-d g:i:s A'),(3,'Mon, DD, YYYY 12:mm:ss','M j, Y g:i:s A');
/*!40000 ALTER TABLE `datetime_format` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `item_class`
--

LOCK TABLES `item_class` WRITE;
/*!40000 ALTER TABLE `item_class` DISABLE KEYS */;
INSERT INTO `item_class` (`item_class_id`, `php_class`, `class_descr`, `relative_image_dir`, `verb`, `one_per_use`, `normal_inventory_display`) VALUES (1,'Food_Item','Food','food','feed','N','Y'),(2,'Toy_Item','Toy','toys','play with','N','Y'),(3,'Paint_Item','Paint','paints','paint','Y','Y'),(4,'Recipe_Item','Recipe','recipe','creates','N','N');
/*!40000 ALTER TABLE `item_class` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:00
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `item_recipe_material`
--

LOCK TABLES `item_recipe_material` WRITE;
/*!40000 ALTER TABLE `item_recipe_material` DISABLE KEYS */;
INSERT INTO `item_recipe_material` (`item_recipe_material_id`, `recipe_item_type_id`, `material_item_type_id`, `material_quantity`) VALUES (1,9,1,2),(2,9,6,1);
/*!40000 ALTER TABLE `item_recipe_material` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `item_recipe_type`
--

LOCK TABLES `item_recipe_type` WRITE;
/*!40000 ALTER TABLE `item_recipe_type` DISABLE KEYS */;
INSERT INTO `item_recipe_type` (`item_recipe_type_id`, `recipe_type_description`) VALUES (1,'Recipe'),(2,'Blueprint');
/*!40000 ALTER TABLE `item_recipe_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `item_type`
--

LOCK TABLES `item_type` WRITE;
/*!40000 ALTER TABLE `item_type` DISABLE KEYS */;
INSERT INTO `item_type` (`item_type_id`, `item_name`, `item_descr`, `item_class_id`, `happiness_bonus`, `hunger_bonus`, `pet_specie_color_id`, `item_image`, `item_recipe_type_id`, `recipe_created_item_type_id`, `recipe_batch_quantity`, `unique_item`, `transferable_item`) VALUES (1,'Red Apple','A delicious, healthy red apple.',1,0,3,0,'apple.png',0,0,0,'N','Y'),(5,'Rozen Paintbrush','<p>The Rozen paintbrush is delicious paint. You must use it~desu!</p>',3,0,0,3,'rozen.png',0,0,0,'N','Y'),(6,'Grubby Bowl','This is an old wooden bowl. Since there is nothing else, your pet will have to amuse itself with this.',2,1,0,0,'bowl.png',0,0,0,'N','Y'),(7,'Red Paintbrush','This will turn your pet red.',3,0,0,1,'red.png',0,0,0,'N','Y'),(8,'Blue Paintbrush','This will turn your pet blue.',3,0,0,1,'blue.png',0,0,0,'N','Y'),(9,'Apple Pie','A recipe for an apple pie.',4,0,0,0,'recipe_pie.png',1,10,1,'Y','N'),(10,'Apple Pie','A warm apple pie.',1,0,5,0,'apple_pie.png',0,0,0,'N','Y');
/*!40000 ALTER TABLE `item_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:00
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `jump_page`
--

LOCK TABLES `jump_page` WRITE;
/*!40000 ALTER TABLE `jump_page` DISABLE KEYS */;
INSERT INTO `jump_page` (`jump_page_id`, `page_title`, `page_html_title`, `layout_type`, `show_layout`, `page_slug`, `access_level`, `restricted_permission_api_name`, `php_script`, `include_tinymce`, `active`) VALUES (1,'Home','Home','deep','Y','home','public','','meta/home.php','N','Y'),(2,'Register','Register','deep','Y','register','public','','user/register.php','N','Y'),(3,'Logoff','Logoff','deep','Y','logoff','user','','user/logout.php','N','Y'),(4,'Login','Login','deep','Y','login','public','','user/login.php','N','Y'),(14,'Profile','Profile','deep','Y','profile','user','','user/profile.php','N','Y'),(22,'Pets','Pets','deep','Y','pets','user','','pets/manage.php','N','Y'),(23,'Pets - Create','Pets - Create','deep','Y','create-pet','user','','pets/create.php','N','Y'),(24,'Pets - Abandon','Pets - Abandon','deep','Y','abandon-pet','user','','pets/abandon.php','N','Y'),(25,'Items','Items','deep','Y','items','user','','items/list.php','N','Y'),(26,'Item - Details','Item - Details','deep','Y','item','user','','items/detail.php','N','Y'),(27,'Shops','Shops','deep','Y','shops','user','','shops/list.php','N','Y'),(28,'Shops - View Stock','Shops - View Stock','deep','Y','shop','user','','shops/shop.php','N','Y'),(29,'Notices','Notices','deep','Y','notice','user','','user/notices.php','N','Y'),(30,'Game Corner','Game Corner','deep','Y','games','user','','games/list.php','N','Y'),(31,'Magic Trick','Magic Trick','deep','Y','magic-game','user','','games/magic_game.php','N','Y'),(32,'Boards','Boards','deep','Y','boards','user','','boards/board_list.php','N','Y'),(33,'Boards','Boards','deep','Y','threads','user','','boards/thread_list.php','N','Y'),(34,'Boards','Boards','deep','Y','thread','user','','boards/post_list.php','Y','Y'),(35,'Boards - Reply','Boards - Reply','deep','Y','thread-reply','user','','boards/reply.php','N','Y'),(36,'Create Thread','Create Thread','deep','Y','new-thread','user','','boards/create_thread.php','Y','Y'),(37,'Forum Moderation','Forum Moderation','deep','Y','forum-admin','restricted','moderate','boards/moderation.php','N','Y'),(38,'Edit Post','Edit Post','deep','Y','edit-post','user','','boards/edit_post.php','Y','Y'),(39,'Edit Thread','Edit Thread','deep','Y','edit-thread','user','','boards/edit_thread.php','N','Y'),(40,'Preferences','Preferences','deep','Y','preferences','user','','user/preferences.php','Y','Y'),(41,'Pet Profile','Pet Profile','deep','Y','pet','user','','pets/profile.php','N','Y'),(42,'Edit Pet Profile','Edit Pet Profile','deep','Y','edit-pet','user','','pets/edit.php','Y','Y'),(43,'News','News','deep','Y','news','public','','news/list.php','N','Y'),(44,'Messages','Messages','deep','Y','messages','user','','messages/list.php','N','Y'),(45,'Compose Message','Compose Message','deep','Y','write-message','user','','messages/write.php','Y','Y'),(46,'Send Message','Send Message','deep','Y','send-message','user','','messages/send.php','N','Y'),(47,'Read Message','Read Message','deep','Y','message','user','','messages/view.php','N','Y'),(48,'Admin Overview','Admin Overview','deep','Y','admin','restricted','admin_panel','admin/links.php','N','Y'),(49,'Permission Editor','Permission Editor','deep','Y','admin-permissions','restricted','manage_permissions','admin/permissions/home.php','N','Y'),(50,'Edit Pet Colors','Edit Pet Colors','deep','Y','admin-pet-colors','restricted','manage_pets','admin/pets/colors/home.php','N','Y'),(51,'Edit Pet Species','Edit Pet Species','deep','Y','admin-pet-species','restricted','manage_pets','admin/pets/species/home.php','N','Y'),(52,'User Admin','User Admin','deep','Y','admin-users','restricted','manage_users','admin/user/home.php','Y','Y'),(53,'Board Admin','Board Admin','deep','Y','admin-boards','restricted','manage_boards','admin/boards/home.php','N','Y'),(54,'Shop Admin','Shop Admin','deep','Y','admin-shops','restricted','manage_shops','admin/shops/home.php','N','Y'),(55,'Item Admin','Item Admin','deep','Y','admin-items','restricted','manage_items','admin/items/home.php','N','Y'),(56,'Permission Editor','Permission Editor','deep','Y','admin-permissions-edit','restricted','manage_permissions','admin/permissions/edit.php','Y','Y'),(57,'Board Creator','Board Creator','deep','Y','admin-boards-create','restricted','manage_boards','admin/boards/create.php','N','N'),(58,'Edit Color','Edit Color','deep','Y','admin-pet-colors-edit','restricted','manage_pets','admin/pets/colors/edit.php','N','Y'),(59,'Edit Specie','Edit Specie','deep','Y','admin-pet-species-edit','restricted','manage_pets','admin/pets/species/edit.php','Y','Y'),(60,'Pet to Color Mapping','Pet to Color Mapping','deep','Y','admin-pet-specie-colors','restricted','manage_pets','admin/pets/species/color_mapping.php','N','Y'),(61,'Board Editor','Board Editor','deep','Y','admin-boards-edit','restricted','manage_boards','admin/boards/edit.php','Y','Y'),(62,'Edit Shop','Edit Shop','deep','Y','admin-shops-edit','restricted','manage_shops','admin/shops/edit.php','Y','Y'),(63,'Edit Item','Edit Item','deep','Y','admin-items-edit','restricted','manage_items','admin/items/edit.php','Y','Y'),(64,'New Item','New Item','deep','Y','admin-items-add','restricted','manage_items','admin/items/new.php','N','Y'),(65,'Edit Restocks','Edit Restocks','deep','Y','admin-restock','restricted','manage_items','admin/items/restock/home.php','N','Y'),(66,'Edit Restocks','Edit Restocks','deep','Y','admin-restock-edit','restricted','manage_items','admin/items/restock/edit.php','N','Y'),(67,'Staff','Staff','deep','Y','staff','public','','meta/staff.php','N','Y'),(68,'Reset Password','Reset Password','deep','Y','reset-password','public','','user/forgot_password.php','N','Y'),(69,'Terms and Conditions','Terms and Conditions','deep','Y','terms-and-conditions','public','','meta/terms.php','N','Y'),(70,'Online Users','Online Users','deep','Y','online','public','','meta/online.php','N','Y'),(71,'Search','Search','deep','Y','search','user','','meta/search.php','N','Y'),(72,'AJAX Item Search Callback','','deep','N','item-search-ajax','user','','items/ajax_widget_search.php','N','Y'),(73,'Manage Recipe Materials','Manage Recipe Materials','deep','Y','admin-recipe','restricted','manage_items','admin/items/recipe_materials.php','N','Y'),(74,'Add Recipe Materials','Add Recipe Materials','deep','Y','admin-recipe-add','restricted','manage_items','admin/items/recipe_add_material.php','N','Y'),(75,'Crafting','Crafting','deep','Y','crafting','user','','crafting/list.php','N','Y'),(76,'Crafting','Crafting','deep','Y','craft','user','','crafting/recipe.php','N','Y');
/*!40000 ALTER TABLE `jump_page` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:00
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `pet_specie_color`
--

LOCK TABLES `pet_specie_color` WRITE;
/*!40000 ALTER TABLE `pet_specie_color` DISABLE KEYS */;
INSERT INTO `pet_specie_color` (`pet_specie_color_id`, `color_name`, `color_img`, `base_color`) VALUES (1,'Red','red.png','Y'),(2,'Blue','blue.png','Y'),(3,'Rozen','rozen.png','N');
/*!40000 ALTER TABLE `pet_specie_color` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `pet_specie_pet_specie_color`
--

LOCK TABLES `pet_specie_pet_specie_color` WRITE;
/*!40000 ALTER TABLE `pet_specie_pet_specie_color` DISABLE KEYS */;
INSERT INTO `pet_specie_pet_specie_color` (`pet_specie_pet_specie_color_id`, `pet_specie_id`, `pet_specie_color_id`) VALUES (9,1,1),(2,1,2),(3,1,3),(4,2,1),(5,2,2);
/*!40000 ALTER TABLE `pet_specie_pet_specie_color` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `pet_specie`
--

LOCK TABLES `pet_specie` WRITE;
/*!40000 ALTER TABLE `pet_specie` DISABLE KEYS */;
INSERT INTO `pet_specie` (`pet_specie_id`, `specie_name`, `specie_descr`, `relative_image_dir`, `max_hunger`, `max_happiness`, `available`) VALUES (1,'Kitto','Somehow, someone, somewhere!','kitto',10,10,'Y'),(2,'Zutto','Forever, forever, forever!','zutto',10,10,'Y');
/*!40000 ALTER TABLE `pet_specie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `shop_restock`
--

LOCK TABLES `shop_restock` WRITE;
/*!40000 ALTER TABLE `shop_restock` DISABLE KEYS */;
INSERT INTO `shop_restock` (`shop_restock_id`, `shop_id`, `item_type_id`, `restock_frequency_seconds`, `unixtime_next_restock`, `min_price`, `max_price`, `min_quantity`, `max_quantity`, `store_quantity_cap`) VALUES (1,1,1,3600,1247524172,1,15,5,10,30),(2,1,6,1200,1247521772,5,15,5,10,15),(3,1,8,2600,1247523173,50,100,2,5,10),(4,1,7,2600,1247523173,50,100,2,5,10),(5,1,5,2800,1247523373,1000,5000,1,2,2),(6,1,9,3600,1247524173,100,200,1,3,5);
/*!40000 ALTER TABLE `shop_restock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `shop`
--

LOCK TABLES `shop` WRITE;
/*!40000 ALTER TABLE `shop` DISABLE KEYS */;
INSERT INTO `shop` (`shop_id`, `shop_name`, `shop_image`, `welcome_text`) VALUES (1,'General Store','general_store.png','Welcome to the general store. We can supply you with anything you might need.');
/*!40000 ALTER TABLE `shop` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `staff_group`
--

LOCK TABLES `staff_group` WRITE;
/*!40000 ALTER TABLE `staff_group` DISABLE KEYS */;
INSERT INTO `staff_group` (`staff_group_id`, `group_name`, `group_descr`, `show_staff_group`, `order_by`) VALUES (1,'High Administrators','The High Administrators are the owner(s) of the site. It is their job to coordinate the efforts of all other staff members and keep the site on-course.','Y',-1),(2,'Moderators','Moderators keep the boards running smoothly and deal with user complaints.','Y',0),(14,'Artists','Artists','Y',0),(15,'Writers','Writers create item descriptions and other backstory for the game.','Y',0);
/*!40000 ALTER TABLE `staff_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `staff_permission`
--

LOCK TABLES `staff_permission` WRITE;
/*!40000 ALTER TABLE `staff_permission` DISABLE KEYS */;
INSERT INTO `staff_permission` (`staff_permission_id`, `api_name`, `permission_name`) VALUES (1,'ignore_board_lock','Post In Locked Board'),(2,'delete_post','Delete Post'),(3,'edit_post','Edit Post'),(4,'manage_thread','Lock/Stick Thread'),(5,'admin_panel','Admin Panel Access'),(6,'moderate','Moderation Dropdown'),(7,'manage_permissions','Edit Permissions'),(8,'manage_pets','Edit Pet Species/Colors'),(9,'manage_users','User Manager'),(10,'manage_boards','Manage Boards'),(11,'manage_shops','Manage Shops'),(12,'manage_items','Manage Items'),(13,'forum_access:staff','Forum: Staff Board');
/*!40000 ALTER TABLE `staff_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
-- MySQL dump 10.11
--
-- Host: localhost    Database: kitto
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `timezone`
--

LOCK TABLES `timezone` WRITE;
/*!40000 ALTER TABLE `timezone` DISABLE KEYS */;
INSERT INTO `timezone` (`timezone_id`, `timezone_short_name`, `timezone_long_name`, `timezone_continent`, `timezone_offset`, `order_by`) VALUES (1,'ACDT','Australian Central Daylight Time','Australia',10.5,1),(2,'ACST','Australian Central Standard Time','Australia',9.5,1),(3,'ADT','Atlantic Daylight Time','North America',-3.0,1),(4,'AEDT','Australian Eastern Daylight Time','Australia',11.0,1),(5,'AEST','Australian Eastern Standard Time','Australia',10.0,1),(6,'AKDT','Alaska Daylight Time','North America',-8.0,1),(7,'AKST','Alaska Standard Time','North America',-9.0,1),(8,'AST','Atlantic Standard Time','North America',-4.0,1),(9,'AWDT','Australian Western Daylight Time','Australia',9.0,1),(10,'AWST','Australian Western Standard Time','Australia',8.0,1),(11,'BST','British Summer Time','Europe',1.0,1),(12,'CDT','Central Daylight Time','North America',-5.0,1),(13,'CEDT','Central European Daylight Time','Europe',2.0,1),(14,'CEST','Central European Summer Time','Europe',2.0,1),(15,'CET','Central European Time','Europe',1.0,1),(16,'CST','Central Summer (Daylight) Time','Australia',10.5,1),(17,'CST','Central Standard Time','Australia',9.5,1),(18,'CST','Central Standard Time','North America',-6.0,1),(19,'CXT','Christmas Island Time','Australia',7.0,1),(20,'EDT','Eastern Daylight Time','North America',-4.0,1),(21,'EEDT','Eastern European Daylight Time','Europe',3.0,1),(22,'EEST','Eastern European Summer Time','Europe',3.0,1),(23,'EET','Eastern European Time','Europe',2.0,1),(24,'EST','Eastern Summer (Daylight) Time','Australia',11.0,1),(25,'EST','Eastern Standard Time','Australia',10.0,1),(26,'EST','Eastern Standard Time','North America',-5.0,1),(27,'GMT','Greenwich Mean Time','Europe',0.0,1),(28,'HAA','Heure Avancee de l\'Atlantique','North America',-3.0,1),(29,'HAC','Heure Avancee du Centre','North America',-5.0,1),(30,'HADT','Hawaii-Aleutian Daylight Time','North America',-9.0,1),(31,'HAE','Heure Avancee de l\'Est','North America',-4.0,1),(32,'HAP','Heure Avancee du Pacifique','North America',-7.0,1),(33,'HAR','Heure Avancee des Rocheuses','North America',-6.0,1),(34,'HAST','Hawaii-Aleutian Standard Time','North America',-10.0,1),(35,'HAT','Heure Avancee de Terre-Neuve','North America',-2.5,1),(36,'HAY','Heure Avancee du Yukon','North America',-8.0,1),(37,'HNA','Heure Normale de l\'Atlantique','North America',-4.0,1),(38,'HNC','Heure Normale du Centre','North America',-6.0,1),(39,'HNE','Heure Normale de l\'Est','North America',-5.0,1),(40,'HNP','Heure Normale du Pacifique','North America',-8.0,1),(41,'HNR','Heure Normale des Rocheuses','North America',-7.0,1),(42,'HNT','Heure Normale de Terre-Neuve','North America',-3.5,1),(43,'HNY','Heure Normale du Yukon','North America',-9.0,1),(44,'IST','Irish Summer Time','Europe',1.0,1),(45,'MDT','Mountain Daylight Time','North America',-6.0,1),(46,'MESZ','Mitteleuropaische Sommerzeit','Europe',2.0,1),(47,'MEZ','Mitteleuropaische Zeit','Europe',1.0,1),(48,'MST','Mountain Standard Time','North America',-7.0,1),(49,'NDT','Newfoundland Daylight Time','North America',-2.5,1),(50,'NFT','Norfolk (Island) Time','Australia',11.5,1),(51,'NST','Newfoundland Standard Time','North America',-3.5,1),(52,'PDT','Pacific Daylight Time','North America',-7.0,1),(53,'PST','Pacific Standard Time','North America',-8.0,1),(54,'UTC','Coordinated Universal Time','Europe',0.0,0),(55,'WEDT','Western European Daylight Time','Europe',1.0,1),(56,'WEST','Western European Summer Time','Europe',1.0,1),(57,'WET','Western European Time','Europe',0.0,1),(58,'WST','Western Summer (Daylight) Time','Australia',9.0,1),(59,'WST','Western Standard Time','Australia',8.0,1);
/*!40000 ALTER TABLE `timezone` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 21:59:01
