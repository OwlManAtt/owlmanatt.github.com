function toggleWriteability(id_of_patient, checked) {
    document.getElementById(id_of_patient).disabled = checked;
}