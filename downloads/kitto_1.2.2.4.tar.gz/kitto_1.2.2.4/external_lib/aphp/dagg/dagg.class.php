<?php
/**
 * An ActiveTable-based library for aggregating and working with dimensional data. 
 *
 * @package    ActivePHP 
 * @author     OwlManAtt <owlmanatt@gmail.com> 
 * @copyright  2007, Yasashii Syndicate 
 * @version    2.2.7
 **/

/**
 * TODO!
 *
 * @package    ActivePHP 
 * @author     OwlManAtt <owlmanatt@gmail.com> 
 * @copyright  2007, Yasashii Syndicate
 * @version    Release: @package_version@
 */
class Dagg 
{
    




} // end Dagg

?>
