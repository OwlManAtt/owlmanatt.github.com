<?php
function smarty_modifier_number_format($number)
{
    return number_format($number);
}
?>
