--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: avatar_avatar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('avatar_avatar_id_seq', 2, true);


--
-- Data for Name: avatar; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY avatar (avatar_id, avatar_name, avatar_image, active) FROM stdin;
1	Kitto	kitto.png	Y
2	Zutto	zutto.png	Y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: board_category_board_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('board_category_board_category_id_seq', 3, true);


--
-- Data for Name: board_category; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY board_category (board_category_id, category_name, order_by, required_permission_id) FROM stdin;
1	General	0	0
2	Advertising	1	0
3	Private Boards	100	13
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: board_board_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('board_board_id_seq', 7, true);


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY board (board_id, board_category_id, board_name, board_descr, board_locked, news_source, required_permission_id, order_by) FROM stdin;
1	1	News & Announcements	The latest news and annoucements are posted here.	Y	Y	0	1
2	1	General Chat	Discuss the KittoKittoKitto project here.	N	N	0	3
3	1	Suggestions / Bugs	Found a bug? Have a brilliant, earth-shattering idea? Tell us!	N	N	0	6
6	2	Groups	Organization for player-run groups.	N	N	0	1
4	3	Staff Board	This is a board restricted to staff members.	N	N	13	100
5	2	For Sale	Awesome deals on today	N	N	0	0
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: cron_tab_cron_tab_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('cron_tab_cron_tab_id_seq', 2, true);


--
-- Data for Name: cron_tab; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY cron_tab (cron_tab_id, cron_class, cron_frequency_seconds, unixtime_next_run, enabled) FROM stdin;
1	Job_RestockShops	3600	1208734668	Y
2	Job_UserOnline	300	1208731717	Y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: datetime_format_datetime_format_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('datetime_format_datetime_format_id_seq', 3, true);


--
-- Data for Name: datetime_format; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY datetime_format (datetime_format_id, datetime_format_name, datetime_format) FROM stdin;
1	YYYY-MM-DD 24:MM:SS	Y-m-d H:i:s
2	YYYY-MM-DD 12:MM:SS	Y-m-d g:i:s A
3	Mon, DD, YYYY 12:mm:ss	M j, Y g:i:s A
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: item_class_item_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('item_class_item_class_id_seq', 3, true);


--
-- Data for Name: item_class; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY item_class (item_class_id, php_class, class_descr, relative_image_dir, verb, one_per_use) FROM stdin;
1	Food_Item	Food	food	feed	N
2	Toy_Item	Toy	toys	play with	N
3	Paint_Item	Paint	paints	paint	Y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: item_type_item_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('item_type_item_type_id_seq', 9, true);


--
-- Data for Name: item_type; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY item_type (item_type_id, item_name, item_descr, item_class_id, happiness_bonus, hunger_bonus, pet_specie_color_id, item_image) FROM stdin;
1	Red Apple	A delicious, healthy red apple.	1	0	3	0	apple.png
6	Grubby Bowl	This is an old wooden bowl. Since there is nothing else, your pet will have to amuse itself with this.	2	1	0	0	bowl.png
7	Red Paintbrush	This will turn your pet red.	3	0	0	1	red.png
8	Blue Paintbrush	This will turn your pet blue.	3	0	0	1	blue.png
5	Rozen Paintbrush	<p>The Rozen paintbrush is delicious paint. You must use it~desu!</p>	3	0	0	3	rozen.png
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: jump_page_jump_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('jump_page_jump_page_id_seq', 71, true);


--
-- Data for Name: jump_page; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY jump_page (jump_page_id, page_title, page_html_title, layout_type, page_slug, access_level, restricted_permission_api_name, php_script, include_tinymce, active) FROM stdin;
1	Home	Home	deep	home	public		meta/home.php	N	Y
2	Register	Register	deep	register	public		user/register.php	N	Y
3	Logoff	Logoff	deep	logoff	user		user/logout.php	N	Y
4	Login	Login	deep	login	public		user/login.php	N	Y
14	Profile	Profile	deep	profile	user		user/profile.php	N	Y
22	Pets	Pets	deep	pets	user		pets/manage.php	N	Y
23	Pets - Create	Pets - Create	deep	create-pet	user		pets/create.php	N	Y
24	Pets - Abandon	Pets - Abandon	deep	abandon-pet	user		pets/abandon.php	N	Y
25	Items	Items	deep	items	user		items/list.php	N	Y
26	Item - Details	Item - Details	deep	item	user		items/detail.php	N	Y
27	Shops	Shops	deep	shops	user		shops/list.php	N	Y
28	Shops - View Stock	Shops - View Stock	deep	shop	user		shops/shop.php	N	Y
29	Notices	Notices	deep	notice	user		user/notices.php	N	Y
30	Game Corner	Game Corner	deep	games	user		games/list.php	N	Y
31	Magic Trick	Magic Trick	deep	magic-game	user		games/magic_game.php	N	Y
32	Boards	Boards	deep	boards	user		boards/board_list.php	N	Y
33	Boards	Boards	deep	threads	user		boards/thread_list.php	N	Y
34	Boards	Boards	deep	thread	user		boards/post_list.php	Y	Y
35	Boards - Reply	Boards - Reply	deep	thread-reply	user		boards/reply.php	N	Y
36	Create Thread	Create Thread	deep	new-thread	user		boards/create_thread.php	Y	Y
37	Forum Moderation	Forum Moderation	deep	forum-admin	restricted	moderate	boards/moderation.php	N	Y
38	Edit Post	Edit Post	deep	edit-post	user		boards/edit_post.php	Y	Y
39	Edit Thread	Edit Thread	deep	edit-thread	user		boards/edit_thread.php	N	Y
40	Preferences	Preferences	deep	preferences	user		user/preferences.php	Y	Y
41	Pet Profile	Pet Profile	deep	pet	user		pets/profile.php	N	Y
42	Edit Pet Profile	Edit Pet Profile	deep	edit-pet	user		pets/edit.php	Y	Y
43	News	News	deep	news	public		news/list.php	N	Y
44	Messages	Messages	deep	messages	user		messages/list.php	N	Y
45	Compose Message	Compose Message	deep	write-message	user		messages/write.php	Y	Y
46	Send Message	Send Message	deep	send-message	user		messages/send.php	N	Y
47	Read Message	Read Message	deep	message	user		messages/view.php	N	Y
48	Admin Overview	Admin Overview	deep	admin	restricted	admin_panel	admin/links.php	N	Y
49	Permission Editor	Permission Editor	deep	admin-permissions	restricted	manage_permissions	admin/permissions/home.php	N	Y
50	Edit Pet Colors	Edit Pet Colors	deep	admin-pet-colors	restricted	manage_pets	admin/pets/colors/home.php	N	Y
51	Edit Pet Species	Edit Pet Species	deep	admin-pet-species	restricted	manage_pets	admin/pets/species/home.php	N	Y
52	User Admin	User Admin	deep	admin-users	restricted	manage_users	admin/user/home.php	Y	Y
53	Board Admin	Board Admin	deep	admin-boards	restricted	manage_boards	admin/boards/home.php	N	Y
54	Shop Admin	Shop Admin	deep	admin-shops	restricted	manage_shops	admin/shops/home.php	N	Y
55	Item Admin	Item Admin	deep	admin-items	restricted	manage_items	admin/items/home.php	N	Y
56	Permission Editor	Permission Editor	deep	admin-permissions-edit	restricted	manage_permissions	admin/permissions/edit.php	Y	Y
57	Board Creator	Board Creator	deep	admin-boards-create	restricted	manage_boards	admin/boards/create.php	N	N
58	Edit Color	Edit Color	deep	admin-pet-colors-edit	restricted	manage_pets	admin/pets/colors/edit.php	N	Y
59	Edit Specie	Edit Specie	deep	admin-pet-species-edit	restricted	manage_pets	admin/pets/species/edit.php	Y	Y
60	Pet to Color Mapping	Pet to Color Mapping	deep	admin-pet-specie-colors	restricted	manage_pets	admin/pets/species/color_mapping.php	N	Y
61	Board Editor	Board Editor	deep	admin-boards-edit	restricted	manage_boards	admin/boards/edit.php	Y	Y
62	Edit Shop	Edit Shop	deep	admin-shops-edit	restricted	manage_shops	admin/shops/edit.php	Y	Y
63	Edit Item	Edit Item	deep	admin-items-edit	restricted	manage_items	admin/items/edit.php	Y	Y
64	New Item	New Item	deep	admin-items-add	restricted	manage_items	admin/items/new.php	N	Y
65	Edit Restocks	Edit Restocks	deep	admin-restock	restricted	manage_items	admin/items/restock/home.php	N	Y
66	Edit Restocks	Edit Restocks	deep	admin-restock-edit	restricted	manage_items	admin/items/restock/edit.php	N	Y
67	Staff	Staff	deep	staff	public		meta/staff.php	N	Y
68	Reset Password	Reset Password	deep	reset-password	public		user/forgot_password.php	N	Y
69	Terms and Conditions	Terms and Conditions	deep	terms-and-conditions	public		meta/terms.php	N	Y
70	Online Users	Online Users	deep	online	public		meta/online.php	N	Y
71	Search	Search	deep	search	user		meta/search.php	N	Y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: pet_specie_color_pet_specie_color_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('pet_specie_color_pet_specie_color_id_seq', 4, true);


--
-- Data for Name: pet_specie_color; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY pet_specie_color (pet_specie_color_id, color_name, color_img, base_color) FROM stdin;
1	Red	red.png	Y
3	Rozen	rozen.png	N
2	Blue	blue.png	Y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: pet_specie_pet_specie_color_pet_specie_pet_specie_color_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('pet_specie_pet_specie_color_pet_specie_pet_specie_color_id_seq', 10, true);


--
-- Data for Name: pet_specie_pet_specie_color; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY pet_specie_pet_specie_color (pet_specie_pet_specie_color_id, pet_specie_id, pet_specie_color_id) FROM stdin;
9	1	1
3	1	3
4	2	1
5	2	2
1	1	2
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: pet_specie_pet_specie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('pet_specie_pet_specie_id_seq', 3, true);


--
-- Data for Name: pet_specie; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY pet_specie (pet_specie_id, specie_name, specie_descr, relative_image_dir, max_hunger, max_happiness, available) FROM stdin;
2	Zutto	Forever, forever, forever!	zutto	10	10	Y
1	Kitto	<p>Somehow, someone, somewhere!</p>	kitto	10	10	Y
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: shop_restock_shop_restock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('shop_restock_shop_restock_id_seq', 6, true);


--
-- Data for Name: shop_restock; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY shop_restock (shop_restock_id, shop_id, item_type_id, restock_frequency_seconds, unixtime_next_restock, min_price, max_price, min_quantity, max_quantity, store_quantity_cap) FROM stdin;
5	1	5	2800	1208733868	1000	5000	1	2	2
3	1	8	2600	1208733668	50	100	2	5	10
4	1	7	2600	1208733668	50	100	2	5	10
2	1	6	1200	1208732268	5	15	5	10	15
1	1	1	3600	1208734668	1	15	5	10	30
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: shop_shop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('shop_shop_id_seq', 2, true);


--
-- Data for Name: shop; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY shop (shop_id, shop_name, shop_image, welcome_text) FROM stdin;
1	General Store	general_store.png	Welcome to the general store. We can supply you with anything you might need.
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: staff_group_staff_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('staff_group_staff_group_id_seq', 19, true);


--
-- Data for Name: staff_group; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY staff_group (staff_group_id, group_name, group_descr, show_staff_group, order_by) FROM stdin;
1	High Administrators	The High Administrators are the owner(s) of the site. It is their job to coordinate the efforts of all other staff members and keep the site on-course.	Y	-1
2	Moderators	Moderators keep the boards running smoothly and deal with user complaints.	Y	0
15	Writers	Writers create item descriptions and other backstory for the game.	Y	0
14	Artists	Artists. They draw pictures.	Y	0
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: staff_permission_staff_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('staff_permission_staff_permission_id_seq', 13, true);


--
-- Data for Name: staff_permission; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY staff_permission (staff_permission_id, api_name, permission_name) FROM stdin;
1	ignore_board_lock	Post In Locked Board
2	delete_post	Delete Post
3	edit_post	Edit Post
4	manage_thread	Lock/Stick Thread
5	admin_panel	Admin Panel Access
6	moderate	Moderation Dropdown
7	manage_permissions	Edit Permissions
8	manage_pets	Edit Pet Species/Colors
9	manage_users	User Manager
10	manage_boards	Manage Boards
11	manage_shops	Manage Shops
12	manage_items	Manage Items
13	forum_access:staff	Forum: Staff Board
\.


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: timezone_timezone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kitto
--

SELECT pg_catalog.setval('timezone_timezone_id_seq', 59, true);


--
-- Data for Name: timezone; Type: TABLE DATA; Schema: public; Owner: kitto
--

COPY timezone (timezone_id, timezone_short_name, timezone_long_name, timezone_continent, timezone_offset, order_by) FROM stdin;
1	ACDT	Australian Central Daylight Time	Australia	10.5	1
2	ACST	Australian Central Standard Time	Australia	9.5	1
3	ADT	Atlantic Daylight Time	North America	-3	1
4	AEDT	Australian Eastern Daylight Time	Australia	11	1
5	AEST	Australian Eastern Standard Time	Australia	10	1
6	AKDT	Alaska Daylight Time	North America	-8	1
7	AKST	Alaska Standard Time	North America	-9	1
8	AST	Atlantic Standard Time	North America	-4	1
9	AWDT	Australian Western Daylight Time	Australia	9	1
10	AWST	Australian Western Standard Time	Australia	8	1
11	BST	British Summer Time	Europe	1	1
12	CDT	Central Daylight Time	North America	-5	1
13	CEDT	Central European Daylight Time	Europe	2	1
14	CEST	Central European Summer Time	Europe	2	1
15	CET	Central European Time	Europe	1	1
16	CST	Central Summer (Daylight) Time	Australia	10.5	1
17	CST	Central Standard Time	Australia	9.5	1
18	CST	Central Standard Time	North America	-6	1
19	CXT	Christmas Island Time	Australia	7	1
20	EDT	Eastern Daylight Time	North America	-4	1
21	EEDT	Eastern European Daylight Time	Europe	3	1
22	EEST	Eastern European Summer Time	Europe	3	1
23	EET	Eastern European Time	Europe	2	1
24	EST	Eastern Summer (Daylight) Time	Australia	11	1
25	EST	Eastern Standard Time	Australia	10	1
26	EST	Eastern Standard Time	North America	-5	1
27	GMT	Greenwich Mean Time	Europe	0	1
28	HAA	Heure Avancee de l'Atlantique	North America	-3	1
29	HAC	Heure Avancee du Centre	North America	-5	1
30	HADT	Hawaii-Aleutian Daylight Time	North America	-9	1
31	HAE	Heure Avancee de l'Est	North America	-4	1
32	HAP	Heure Avancee du Pacifique	North America	-7	1
33	HAR	Heure Avancee des Rocheuses	North America	-6	1
34	HAST	Hawaii-Aleutian Standard Time	North America	-10	1
35	HAT	Heure Avancee de Terre-Neuve	North America	-2.5	1
36	HAY	Heure Avancee du Yukon	North America	-8	1
37	HNA	Heure Normale de l'Atlantique	North America	-4	1
38	HNC	Heure Normale du Centre	North America	-6	1
39	HNE	Heure Normale de l'Est	North America	-5	1
40	HNP	Heure Normale du Pacifique	North America	-8	1
41	HNR	Heure Normale des Rocheuses	North America	-7	1
42	HNT	Heure Normale de Terre-Neuve	North America	-3.5	1
43	HNY	Heure Normale du Yukon	North America	-9	1
44	IST	Irish Summer Time	Europe	1	1
45	MDT	Mountain Daylight Time	North America	-6	1
46	MESZ	Mitteleuropaische Sommerzeit	Europe	2	1
47	MEZ	Mitteleuropaische Zeit	Europe	1	1
48	MST	Mountain Standard Time	North America	-7	1
49	NDT	Newfoundland Daylight Time	North America	-2.5	1
50	NFT	Norfolk (Island) Time	Australia	11.5	1
51	NST	Newfoundland Standard Time	North America	-3.5	1
52	PDT	Pacific Daylight Time	North America	-7	1
53	PST	Pacific Standard Time	North America	-8	1
54	UTC	Coordinated Universal Time	Europe	0	0
55	WEDT	Western European Daylight Time	Europe	1	1
56	WEST	Western European Summer Time	Europe	1	1
57	WET	Western European Time	Europe	0	1
58	WST	Western Summer (Daylight) Time	Australia	9	1
59	WST	Western Standard Time	Australia	8	1
\.


--
-- PostgreSQL database dump complete
--

