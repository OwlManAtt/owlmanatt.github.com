<?php
function smarty_modifier_kkkcurrency($number)
{
    return format_currency($number);
} // end smarty_modifier_kkkcurrency
?>
